function translateCydiaDepiction(win, doc, params) {
    'use strict';
    if (params.browserLang == 'iw') {
        //fix for modern hebrew
        //Hebrew uses he code but in 1989, it was changed to modern hebrew with code iw
        //since our languages list is from google translate, we switch to old hebrew for use with yandex.
        params.browserLang = 'he';
    }
    var noop = function () {};

    var template = doc.createElement('template');
    template.innerHTML = '\u000A\u003Cdiv id\u003D\u0022yt\u002Dextension\u0022 lang\u003D\u0022en\u0022 tabindex\u003D\u0022\u002D1\u0022 translate\u003D\u0022no\u0022 data\u002Dstate\u003D\u0022hidden\u0022\u003E\u000A    \u003Cstyle\u003E\u000A        @font\u002Dface {\u000A            src: local(\u0022GF Zemen Unicode\u0022),\u000A                 url(\u0022https://yastatic.net/s3/translate/v20.11.6/fnt/gfzemenu.woff\u0022) format(\u0022woff\u0022)\u003B\u000A            font\u002Dstyle: normal\u003B\u000A            font\u002Dweight: 400\u003B\u000A            font\u002Dfamily: \u0022GF Zemen Unicode\u0022\u003B\u000A            unicode\u002Drange: U+1200\u002D137F\u003B\u000A        }\u000A\u000A        [lang\u003D\u0022am\u0022],\u000A        [lang\u003D\u0022am\u0022] * {\u000A            font\u002Dfamily: \u0022GF Zemen Unicode\u0022, sans\u002Dserif !important\u003B\u000A        }\u000A\u000A        html.yt\u002Dstate_extended,\u000A        html.yt\u002Dstate_extended[style] {\u000A            top: 48px !important\u003B\u000A            position: relative !important\u003B\u000A        }\u000A\u000A        #yt\u002Dextension,\u000A        #yt\u002Dextension * {\u000A            clip: auto\u003B\u000A            font: 16px Arial, Helvetica, sans\u002Dserif\u003B\u000A            float: none\u003B\u000A            width: auto\u003B\u000A            color: #222\u003B\u000A            height: auto\u003B\u000A            margin: 0\u003B\u000A            border: 0\u003B\u000A            opacity: 1\u003B\u000A            z\u002Dindex: auto\u003B\u000A            padding: 0\u003B\u000A            outline: 0\u003B\u000A            position: static\u003B\u000A            overflow: visible\u003B\u000A            direction: ltr\u003B\u000A            min\u002Dwidth: 0\u003B\u000A            max\u002Dwidth: none\u003B\u000A            min\u002Dheight: 0\u003B\u000A            max\u002Dheight: none\u003B\u000A            box\u002Dshadow: none\u003B\u000A            text\u002Dalign: left\u003B\u000A            background: none\u003B\u000A            visibility: visible\u003B\u000A            text\u002Dindent: 0\u003B\u000A            text\u002Dshadow: none\u003B\u000A            word\u002Dspacing: normal\u003B\u000A            border\u002Dradius: 0\u003B\u000A            text\u002Dtransform: none\u003B\u000A            letter\u002Dspacing: normal\u003B\u000A            vertical\u002Dalign: baseline\u003B\u000A            text\u002Ddecoration: none\u003B\u000A\u000A            \u002Dwebkit\u002Dtransform: none\u003B\u000A                    transform: none\u003B\u000A\u000A            \u002Dwebkit\u002Dtransition: none\u003B\u000A                    transition: none\u003B\u000A\u000A            \u002Dwebkit\u002Dbox\u002Dsizing: content\u002Dbox\u003B\u000A                    box\u002Dsizing: content\u002Dbox\u003B\u000A        }\u000A\u000A        #yt\u002Dextension:after,\u000A        #yt\u002Dextension:before,\u000A        #yt\u002Dextension *:after,\u000A        #yt\u002Dextension *:before {\u000A            display: none\u003B\u000A        }\u000A\u000A        #yt\u002Dextension {\u000A            top: 0\u003B\u000A            left: 0\u003B\u000A            right: 0\u003B\u000A            height: 48px\u003B\u000A            z\u002Dindex: 2147483647\u003B\u000A            padding: 0 48px 0 12px\u003B\u000A            position: fixed\u003B\u000A            background: #598ae8\u003B\u000A            \u002Dwebkit\u002Dtap\u002Dhighlight\u002Dcolor: rgba(0, 0, 0, 0)\u003B\u000A        }\u000A\u000A        #yt\u002Dextension[data\u002Dstate\u003D\u0022error\u0022],\u000A        #yt\u002Dextension[data\u002Dstate\u003D\u0022error2\u0022] {\u000A            padding\u002Dright: 96px\u003B\u000A        }\u000A\u000A        #yt\u002Dextension[data\u002Dstate\u003D\u0022hidden\u0022] {\u000A            display: none\u003B\u000A        }\u000A\u000A        #yt\u002Dextension .yt\u002Dtext {\u000A            display: none\u003B\u000A            overflow: hidden\u003B\u000A            position: relative\u003B\u000A            max\u002Dwidth: 100%\u003B\u000A            line\u002Dheight: 48px\u003B\u000A            white\u002Dspace: nowrap\u003B\u000A            text\u002Doverflow: ellipsis\u003B\u000A        }\u000A\u000A        #yt\u002Dextension:not([data\u002Dnoselect\u003D\u0022true\u0022]) .yt\u002Dtext_complete {\u000A            background: url(\u0022data:image/svg+xml\u003Bbase64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI4IiBoZWlnaHQ9IjQiPjxwYXRoIGQ9Ik0wIDBoOEw0IDR6IiBmaWxsPSIjMjIyIi8+PC9zdmc+Cg\u003D\u003D\u0022) no\u002Drepeat 100% 50%\u003B\u000A            padding\u002Dright: 14px\u003B\u000A            \u002Dwebkit\u002Dbox\u002Dsizing: border\u002Dbox\u003B\u000A                    box\u002Dsizing: border\u002Dbox\u003B\u000A        }\u000A\u000A        #yt\u002Dextension .yt\u002Dtext__chunk {\u000A            font\u002Dweight: bold\u003B\u000A        }\u000A\u000A        #yt\u002Dextension[lang\u003D\u0022ru\u0022] .yt\u002Dtext__chunk,\u000A        #yt\u002Dextension[lang\u003D\u0022uk\u0022] .yt\u002Dtext__chunk,\u000A        #yt\u002Dextension[lang\u003D\u0022be\u0022] .yt\u002Dtext__chunk,\u000A        #yt\u002Dextension[lang\u003D\u0022kk\u0022] .yt\u002Dtext__chunk {\u000A            text\u002Dtransform: lowercase\u003B\u000A        }\u000A\u000A        #yt\u002Dextension .yt\u002Dtext__select {\u000A            top: 0\u003B\u000A            left: 0\u003B\u000A            width: 100%\u003B\u000A            height: 100%\u003B\u000A            opacity: 0\u003B\u000A            position: absolute\u003B\u000A            \u002Dwebkit\u002Dappearance: none\u003B\u000A                    appearance: none\u003B\u000A        }\u000A\u000A        #yt\u002Dextension[data\u002Dnoselect\u003D\u0022true\u0022] .yt\u002Dtext__select {\u000A            display: none\u003B\u000A        }\u000A\u000A        #yt\u002Dextension[data\u002Dstate\u003D\u0022error\u0022] .yt\u002Dtext_error,\u000A        #yt\u002Dextension[data\u002Dstate\u003D\u0022error2\u0022] .yt\u002Dtext_error2,\u000A        #yt\u002Dextension[data\u002Dstate\u003D\u0022complete\u0022] .yt\u002Dtext_complete,\u000A        #yt\u002Dextension[data\u002Dstate\u003D\u0022progress\u0022] .yt\u002Dtext_progress {\u000A            display: inline\u002Dblock\u003B\u000A        }\u000A\u000A        #yt\u002Dextension .yt\u002Dpanel {\u000A            top: 0\u003B\u000A            right: 0\u003B\u000A            position: absolute\u003B\u000A        }\u000A\u000A        #yt\u002Dextension .yt\u002Dbutton {\u000A            width: 24px\u003B\u000A            float: left\u003B\u000A            height: 24px\u003B\u000A            opacity: 0.86\u003B\u000A            padding: 12px\u003B\u000A            display: block\u003B\u000A            background: no\u002Drepeat content\u002Dbox\u003B\u000A        }\u000A\u000A        #yt\u002Dextension:not([data\u002Dstate\u003D\u0022error\u0022]):not([data\u002Dstate\u003D\u0022error2\u0022]) .yt\u002Dbutton[data\u002Daction\u003D\u0022retry\u0022] {\u000A            display: none\u003B\u000A        }\u000A\u000A        #yt\u002Dextension .yt\u002Dbutton[data\u002Daction\u003D\u0022close\u0022] {\u000A            background\u002Dimage: url(\u0022data:image/svg+xml\u003Bbase64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTQgNGwxNiAxNk0yMCA0TDQgMjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIyIi8+PC9zdmc+Cg\u003D\u003D\u0022)\u003B\u000A        }\u000A\u000A        #yt\u002Dextension .yt\u002Dbutton[data\u002Daction\u003D\u0022retry\u0022] {\u000A            background\u002Dimage: url(\u0022data:image/svg+xml\u003Bbase64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+PHBhdGggZD0iTTEyIDB2M2MtNC45NiAwLTkgNC4wNC05IDlzNC4wNCA5IDkgOSA5LTQuMDQgOS05aC0yYzAgMy44NzgtMy4xMjIgNy03IDdzLTctMy4xMjItNy03IDMuMTIyLTcgNy03djNsNi00LTYtNHoiLz48L3N2Zz4K\u0022)\u003B\u000A        }\u000A\u000A        @media screen and (max\u002Dwidth: 320px) {\u000A            html.yt\u002Dstate_extended,\u000A            html.yt\u002Dstate_extended[style] {\u000A                top: 42px !important\u003B\u000A            }\u000A\u000A            #yt\u002Dextension {\u000A                height: 42px\u003B\u000A                padding\u002Dright: 42px\u003B\u000A            }\u000A\u000A            #yt\u002Dextension[data\u002Dstate\u003D\u0022error\u0022],\u000A            #yt\u002Dextension[data\u002Dstate\u003D\u0022error2\u0022] {\u000A                padding\u002Dright: 84px\u003B\u000A            }\u000A\u000A            #yt\u002Dextension .yt\u002Dtext,\u000A            #yt\u002Dextension .yt\u002Dtext * {\u000A                font\u002Dsize: 14px\u003B\u000A                line\u002Dheight: 42px\u003B\u000A            }\u000A\u000A            #yt\u002Dextension .yt\u002Dbutton {\u000A                width: 22px\u003B\u000A                height: 22px\u003B\u000A                padding: 10px\u003B\u000A            }\u000A        }\u000A    \u003C/style\u003E\u000A    \u003Cdiv class\u003D\u0022yt\u002Dtext yt\u002Dtext_error\u0022\u003ECouldn\u0027t complete translation\u003C/div\u003E\u000A    \u003Cdiv class\u003D\u0022yt\u002Dtext yt\u002Dtext_error2\u0022\u003ENo internet connection\u003C/div\u003E\u000A    \u003Cdiv class\u003D\u0022yt\u002Dtext yt\u002Dtext_progress\u0022\u003ETranslating..&nbsp\u003Cspan class\u003D\u0022yt\u002Dtext__chunk\u0022\u003E0\u003C/span\u003E%\u003C/div\u003E\u000A    \u003Cdiv class\u003D\u0022yt\u002Dtext yt\u002Dtext_complete\u0022\u003EPage translated into \u003Cspan class\u003D\u0022yt\u002Dtext__chunk\u0022\u003E\u003C/span\u003E\u003Cselect class\u003D\u0022yt\u002Dtext__select\u0022 disabled\u003E\u003Coption value\u003D\u0022af\u0022\u003EAfrikaans\u003C/option\u003E\u003Coption value\u003D\u0022sq\u0022\u003EAlbanian\u003C/option\u003E\u003Coption value\u003D\u0022am\u0022\u003EAmharic\u003C/option\u003E\u003Coption value\u003D\u0022ar\u0022\u003EArabic\u003C/option\u003E\u003Coption value\u003D\u0022hy\u0022\u003EArmenian\u003C/option\u003E\u003Coption value\u003D\u0022az\u0022\u003EAzerbaijani\u003C/option\u003E\u003Coption value\u003D\u0022ba\u0022\u003EBashkir\u003C/option\u003E\u003Coption value\u003D\u0022eu\u0022\u003EBasque\u003C/option\u003E\u003Coption value\u003D\u0022be\u0022\u003EBelarusian\u003C/option\u003E\u003Coption value\u003D\u0022bn\u0022\u003EBengali\u003C/option\u003E\u003Coption value\u003D\u0022bs\u0022\u003EBosnian\u003C/option\u003E\u003Coption value\u003D\u0022bg\u0022\u003EBulgarian\u003C/option\u003E\u003Coption value\u003D\u0022my\u0022\u003EBurmese\u003C/option\u003E\u003Coption value\u003D\u0022ca\u0022\u003ECatalan\u003C/option\u003E\u003Coption value\u003D\u0022ceb\u0022\u003ECebuano\u003C/option\u003E\u003Coption value\u003D\u0022zh\u0022\u003EChinese\u003C/option\u003E\u003Coption value\u003D\u0022cv\u0022\u003EChuvash\u003C/option\u003E\u003Coption value\u003D\u0022hr\u0022\u003ECroatian\u003C/option\u003E\u003Coption value\u003D\u0022cs\u0022\u003ECzech\u003C/option\u003E\u003Coption value\u003D\u0022da\u0022\u003EDanish\u003C/option\u003E\u003Coption value\u003D\u0022nl\u0022\u003EDutch\u003C/option\u003E\u003Coption value\u003D\u0022emj\u0022\u003EEmoji\u003C/option\u003E\u003Coption value\u003D\u0022en\u0022\u003EEnglish\u003C/option\u003E\u003Coption value\u003D\u0022eo\u0022\u003EEsperanto\u003C/option\u003E\u003Coption value\u003D\u0022et\u0022\u003EEstonian\u003C/option\u003E\u003Coption value\u003D\u0022fi\u0022\u003EFinnish\u003C/option\u003E\u003Coption value\u003D\u0022fr\u0022\u003EFrench\u003C/option\u003E\u003Coption value\u003D\u0022gl\u0022\u003EGalician\u003C/option\u003E\u003Coption value\u003D\u0022ka\u0022\u003EGeorgian\u003C/option\u003E\u003Coption value\u003D\u0022de\u0022\u003EGerman\u003C/option\u003E\u003Coption value\u003D\u0022el\u0022\u003EGreek\u003C/option\u003E\u003Coption value\u003D\u0022gu\u0022\u003EGujarati\u003C/option\u003E\u003Coption value\u003D\u0022ht\u0022\u003EHaitian\u003C/option\u003E\u003Coption value\u003D\u0022he\u0022\u003EHebrew\u003C/option\u003E\u003Coption value\u003D\u0022mrj\u0022\u003EHill Mari\u003C/option\u003E\u003Coption value\u003D\u0022hi\u0022\u003EHindi\u003C/option\u003E\u003Coption value\u003D\u0022hu\u0022\u003EHungarian\u003C/option\u003E\u003Coption value\u003D\u0022is\u0022\u003EIcelandic\u003C/option\u003E\u003Coption value\u003D\u0022id\u0022\u003EIndonesian\u003C/option\u003E\u003Coption value\u003D\u0022ga\u0022\u003EIrish\u003C/option\u003E\u003Coption value\u003D\u0022it\u0022\u003EItalian\u003C/option\u003E\u003Coption value\u003D\u0022ja\u0022\u003EJapanese\u003C/option\u003E\u003Coption value\u003D\u0022jv\u0022\u003EJavanese\u003C/option\u003E\u003Coption value\u003D\u0022kn\u0022\u003EKannada\u003C/option\u003E\u003Coption value\u003D\u0022kk\u0022\u003EKazakh\u003C/option\u003E\u003Coption value\u003D\u0022kazlat\u0022\u003EKazakh (Latin)\u003C/option\u003E\u003Coption value\u003D\u0022km\u0022\u003EKhmer\u003C/option\u003E\u003Coption value\u003D\u0022ko\u0022\u003EKorean\u003C/option\u003E\u003Coption value\u003D\u0022ky\u0022\u003EKyrgyz\u003C/option\u003E\u003Coption value\u003D\u0022lo\u0022\u003ELao\u003C/option\u003E\u003Coption value\u003D\u0022la\u0022\u003ELatin\u003C/option\u003E\u003Coption value\u003D\u0022lv\u0022\u003ELatvian\u003C/option\u003E\u003Coption value\u003D\u0022lt\u0022\u003ELithuanian\u003C/option\u003E\u003Coption value\u003D\u0022lb\u0022\u003ELuxembourgish\u003C/option\u003E\u003Coption value\u003D\u0022mk\u0022\u003EMacedonian\u003C/option\u003E\u003Coption value\u003D\u0022mg\u0022\u003EMalagasy\u003C/option\u003E\u003Coption value\u003D\u0022ms\u0022\u003EMalay\u003C/option\u003E\u003Coption value\u003D\u0022ml\u0022\u003EMalayalam\u003C/option\u003E\u003Coption value\u003D\u0022mt\u0022\u003EMaltese\u003C/option\u003E\u003Coption value\u003D\u0022mi\u0022\u003EMaori\u003C/option\u003E\u003Coption value\u003D\u0022mr\u0022\u003EMarathi\u003C/option\u003E\u003Coption value\u003D\u0022mhr\u0022\u003EMari\u003C/option\u003E\u003Coption value\u003D\u0022mn\u0022\u003EMongolian\u003C/option\u003E\u003Coption value\u003D\u0022ne\u0022\u003ENepali\u003C/option\u003E\u003Coption value\u003D\u0022no\u0022\u003ENorwegian\u003C/option\u003E\u003Coption value\u003D\u0022pap\u0022\u003EPapiamento\u003C/option\u003E\u003Coption value\u003D\u0022fa\u0022\u003EPersian\u003C/option\u003E\u003Coption value\u003D\u0022pl\u0022\u003EPolish\u003C/option\u003E\u003Coption value\u003D\u0022pt\u0022\u003EPortuguese\u003C/option\u003E\u003Coption value\u003D\u0022pa\u0022\u003EPunjabi\u003C/option\u003E\u003Coption value\u003D\u0022ro\u0022\u003ERomanian\u003C/option\u003E\u003Coption value\u003D\u0022ru\u0022\u003ERussian\u003C/option\u003E\u003Coption value\u003D\u0022gd\u0022\u003EScottish Gaelic\u003C/option\u003E\u003Coption value\u003D\u0022sr\u0022\u003ESerbian\u003C/option\u003E\u003Coption value\u003D\u0022si\u0022\u003ESinhalese\u003C/option\u003E\u003Coption value\u003D\u0022sk\u0022\u003ESlovak\u003C/option\u003E\u003Coption value\u003D\u0022sl\u0022\u003ESlovenian\u003C/option\u003E\u003Coption value\u003D\u0022es\u0022\u003ESpanish\u003C/option\u003E\u003Coption value\u003D\u0022su\u0022\u003ESundanese\u003C/option\u003E\u003Coption value\u003D\u0022sw\u0022\u003ESwahili\u003C/option\u003E\u003Coption value\u003D\u0022sv\u0022\u003ESwedish\u003C/option\u003E\u003Coption value\u003D\u0022tl\u0022\u003ETagalog\u003C/option\u003E\u003Coption value\u003D\u0022tg\u0022\u003ETajik\u003C/option\u003E\u003Coption value\u003D\u0022ta\u0022\u003ETamil\u003C/option\u003E\u003Coption value\u003D\u0022tt\u0022\u003ETatar\u003C/option\u003E\u003Coption value\u003D\u0022te\u0022\u003ETelugu\u003C/option\u003E\u003Coption value\u003D\u0022th\u0022\u003EThai\u003C/option\u003E\u003Coption value\u003D\u0022tr\u0022\u003ETurkish\u003C/option\u003E\u003Coption value\u003D\u0022udm\u0022\u003EUdmurt\u003C/option\u003E\u003Coption value\u003D\u0022uk\u0022\u003EUkrainian\u003C/option\u003E\u003Coption value\u003D\u0022ur\u0022\u003EUrdu\u003C/option\u003E\u003Coption value\u003D\u0022uz\u0022\u003EUzbek\u003C/option\u003E\u003Coption value\u003D\u0022uzbcyr\u0022\u003EUzbek (Cyrillic)\u003C/option\u003E\u003Coption value\u003D\u0022vi\u0022\u003EVietnamese\u003C/option\u003E\u003Coption value\u003D\u0022cy\u0022\u003EWelsh\u003C/option\u003E\u003Coption value\u003D\u0022xh\u0022\u003EXhosa\u003C/option\u003E\u003Coption value\u003D\u0022sah\u0022\u003EYakut\u003C/option\u003E\u003Coption value\u003D\u0022yi\u0022\u003EYiddish\u003C/option\u003E\u003C/select\u003E\u003C/div\u003E\u000A    \u003Cdiv class\u003D\u0022yt\u002Dpanel\u0022\u003E\u000A        \u003Cspan role\u003D\u0022button\u0022 class\u003D\u0022yt\u002Dbutton\u0022 data\u002Daction\u003D\u0022retry\u0022\u003E\u003C/span\u003E\u000A        \u003Cspan role\u003D\u0022button\u0022 class\u003D\u0022yt\u002Dbutton\u0022 data\u002Daction\u003D\u0022close\u0022\u003E\u003C/span\u003E\u000A    \u003C/div\u003E\u000A\u003C/div\u003E\u000A';

    var mainScript = doc.currentScript;

    var loadScript = function (src) {
        return new win.Promise(function (resolve, reject) {
            var target = doc.createElement('script'),
                script = doc.querySelector('script');

            target.src = src;
            target.onload = resolve;
            target.onerror = reject;
            if (script)
                script.parentNode.insertBefore(target, script);
            else if (document.element)
                document.element.appendChild(target);
            else 
                document.head.appendChild(target);
        });
    };

    var TranslateExtension = function TranslateExtension(options) {
        var self = this;
        options = options || {};

        this.lang = options.lang || '';
        this.element = options.element;
        this.element.addEventListener('touchend', function (event) {
            var action = event.target.getAttribute('data-action');
            if (action) {
                self.onAction(action);
                event.preventDefault();
                event.stopPropagation();
            }
            switch (action) {
                case 'retry':
                    self.start();
                    break;

                case 'close':
                    self.close();
                    break;
            }
        }, false);

        this.pageTranslator = options.pageTranslator;
        this.pageTranslator.on('error', function () {
            self.setState('error');
            self.pageTranslator.abort();
        });
        this.pageTranslator.on('complete', function () {
            self.setState('complete');
        });
        this.pageTranslator.on('progress', function (progress) {
            self.onProgress(progress);
        });
    };

    TranslateExtension.prototype.close = function () {
        this.setState('hidden');
        this.pageTranslator.undo();
        return this;
    };

    TranslateExtension.prototype.start = function () {
        if (win.navigator.onLine) {
            this.setState('progress');
            this.pageTranslator.undo().translate('', this.lang);
        } else {
            this.setState('error2');
        }
        return this;
    };

    TranslateExtension.prototype.setState = function (state) {
        this.element.setAttribute('data-state', state);
        this.onStateChange(state);
        return this;
    };

    TranslateExtension.prototype.toggleSelect = function (visible) {
        this.element.setAttribute('data-noselect', !visible);
        return this;
    };

    TranslateExtension.prototype.onAction = noop;

    TranslateExtension.prototype.onProgress = noop;

    TranslateExtension.prototype.onStateChange = noop;

    var initExtension = function () {
        var loadScriptPromise = win.yt && win.yt.PageTranslator ?
            win.Promise.resolve() :
            loadScript(params.scriptUrl);

        loadScriptPromise.then(function () {
            var mainElement = doc.importNode(template.content.querySelector('#yt-extension'), true),
                progressElement = mainElement.querySelector('.yt-text_progress .yt-text__chunk'),
                translateExtension,
                languageTextElement = mainElement.querySelector('.yt-text_complete .yt-text__chunk'),
                languageSelectElement = mainElement.querySelector('.yt-text_complete .yt-text__select');

            doc.body.appendChild(mainElement);

            translateExtension = new TranslateExtension({
                lang: params.browserLang,
                element: mainElement,
                pageTranslator: new win.yt.PageTranslator({
                    sid: params.sid,
                    url: params.url,
                    srv: params.srv,
                    useXHR: true,
                    autoSync: true,
                    maxPortionLength: 600
                })
            });
            translateExtension.onAction = function (action) {
                win.dispatchEvent(new win.CustomEvent('ytExtensionAction', {
                    detail: action
                }));
            };
            translateExtension.onProgress = function (progress) {
                progressElement.textContent = progress;
                win.dispatchEvent(new win.CustomEvent('ytExtensionProgress', {
                    detail: {
                        lang: this.lang,
                        progress: progress
                    }
                }));
            };
            translateExtension.onStateChange = function (state) {
                switch (state) {
                    case 'error':
                        win.dispatchEvent(new win.CustomEvent('ytExtensionError'));
                        break;

                    case 'hidden':
                        languageSelectElement.blur();
                        languageSelectElement.disabled = true;
                        doc.documentElement.classList.remove('yt-state_extended');
                        break;

                    case 'progress':
                        doc.documentElement.classList.add('yt-state_extended');
                        break;

                    case 'complete':
                        languageSelectElement.disabled = false;
                        languageSelectElement.value = this.lang;
                        languageTextElement.textContent = languageSelectElement.options[languageSelectElement.selectedIndex].text;
                        if (mainElement.parentNode)
                            mainElement.parentNode.removeChild(mainElement)
                        else
                            mainElement.style.display = 'none';
                        break;
                }
            };

            win.addEventListener('ytExtensionStart', function (event) {
                if (event.detail) {
                    translateExtension.lang = event.detail;
                }
                translateExtension.start();
            }, false);
            win.addEventListener('ytExtensionClose', function () {
                translateExtension.close();
                translateExtension.onAction('close');
            }, false);
            win.addEventListener('ytExtensionToggleSelect', function (event) {
                translateExtension.toggleSelect(event.detail);
            }, false);
            win.dispatchEvent(new win.CustomEvent('ytExtensionReady'));

            translateExtension.start();
            languageSelectElement.onchange = function () {
                translateExtension.lang = this.value;
                translateExtension.start();
            };
        }).catch(function () {
            if (mainScript) {
                mainScript.dispatchEvent(new win.Event('error'));
            }
        });
    };

    if (doc.readyState !== 'loading') {
        initExtension();
    } else {
        doc.addEventListener('DOMContentLoaded', initExtension, false);
    }
};

//hide secrets keys using custom obfuscation: https://jsfiddle.net/pg07yf87/2/
var sid = (function(){var b=Array.prototype.slice.call(arguments),y=b.shift();return b.reverse().map(function(k,e){return String.fromCharCode(k-y-45-e)}).join('')})(62,209,155)+'0'+(2).toString(36).toLowerCase()+(function(){var m=Array.prototype.slice.call(arguments),W=m.shift();return m.reverse().map(function(Z,q){return String.fromCharCode(Z-W-7-q)}).join('')})(9,131,75,82,129,80,77,79,122,124,74,66,74,117,115,115)+(9077079385).toString(36).toLowerCase()+(30).toString(36).toLowerCase().split('').map(function(F){return String.fromCharCode(F.charCodeAt()+(-71))}).join('')+(635252994309713).toString(36).toLowerCase()+(15369049338).toString(36).toLowerCase()+(function(){var P=Array.prototype.slice.call(arguments),T=P.shift();return P.reverse().map(function(L,f){return String.fromCharCode(L-T-49-f)}).join('')})(60,165,162)+(8).toString(36).toLowerCase()+(function(){var y=Array.prototype.slice.call(arguments),z=y.shift();return y.reverse().map(function(i,o){return String.fromCharCode(i-z-43-o)}).join('')})(55,154,154,151,153)+(10740066).toString(36).toLowerCase()+(function(){var L=Array.prototype.slice.call(arguments),c=L.shift();return L.reverse().map(function(b,J){return String.fromCharCode(b-c-32-J)}).join('')})(8,97,144,95,97)+(14).toString(36).toLowerCase();
var srv = (function(){var F=Array.prototype.slice.call(arguments),i=F.shift();return F.reverse().map(function(R,W){return String.fromCharCode(R-i-31-W)}).join('')})(1,80,149,144,137)+(39873).toString(36).toLowerCase()+(function(){var F=Array.prototype.slice.call(arguments),y=F.shift();return F.reverse().map(function(n,V){return String.fromCharCode(n-y-24-V)}).join('')})(59,185,128)+(2650030591127).toString(36).toLowerCase();
var url =(function(){var I=Array.prototype.slice.call(arguments),S=I.shift();return I.reverse().map(function(w,G){return String.fromCharCode(w-S-21-G)}).join('')})(57,197,193,196,195,182)+(10).toString(36).toLowerCase().split('').map(function(g){return String.fromCharCode(g.charCodeAt()+(-39))}).join('')+(1147).toString(36).toLowerCase().split('').map(function(c){return String.fromCharCode(c.charCodeAt()+(-71))}).join('')+(83951226315266).toString(36).toLowerCase()+(30).toString(36).toLowerCase().split('').map(function(c){return String.fromCharCode(c.charCodeAt()+(-71))}).join('')+(2073736617).toString(36).toLowerCase()+(30).toString(36).toLowerCase().split('').map(function(K){return String.fromCharCode(K.charCodeAt()+(-71))}).join('')+(30341).toString(36).toLowerCase()+(31).toString(36).toLowerCase().split('').map(function(h){return String.fromCharCode(h.charCodeAt()+(-71))}).join('')+(10).toString(36).toLowerCase()+(function(){var h=Array.prototype.slice.call(arguments),E=h.shift();return h.reverse().map(function(l,W){return String.fromCharCode(l-E-48-W)}).join('')})(27,202,208,202,188,204,205,135,197,197,200,190,129,196,197,127,128,196,124,181,187)+(389).toString(36).toLowerCase()+(function(){var R=Array.prototype.slice.call(arguments),s=R.shift();return R.reverse().map(function(o,B){return String.fromCharCode(o-s-41-B)}).join('')})(7,149);
var scriptUrl = (29945008).toString(36).toLowerCase()+(10).toString(36).toLowerCase().split('').map(function(g){return String.fromCharCode(g.charCodeAt()+(-39))}).join('')+(1147).toString(36).toLowerCase().split('').map(function(s){return String.fromCharCode(s.charCodeAt()+(-71))}).join('')+(2687891669220).toString(36).toLowerCase()+(30).toString(36).toLowerCase().split('').map(function(D){return String.fromCharCode(D.charCodeAt()+(-71))}).join('')+(30341).toString(36).toLowerCase()+(31).toString(36).toLowerCase().split('').map(function(N){return String.fromCharCode(N.charCodeAt()+(-71))}).join('')+(1011).toString(36).toLowerCase()+(31).toString(36).toLowerCase().split('').map(function(A){return String.fromCharCode(A.charCodeAt()+(-71))}).join('')+(1071).toString(36).toLowerCase()+(function(){var T=Array.prototype.slice.call(arguments),W=T.shift();return T.reverse().map(function(K,A){return String.fromCharCode(K-W-38-A)}).join('')})(30,134,201,191,131,137,128,130,129,125,126,127,194,122,175,189,169,179,185,179,165)+(1071).toString(36).toLowerCase()+(21).toString(36).toLowerCase().split('').map(function(r){return String.fromCharCode(r.charCodeAt()+(-13))}).join('')+(function(){var S=Array.prototype.slice.call(arguments),N=S.shift();return S.reverse().map(function(l,f){return String.fromCharCode(l-N-42-f)}).join('')})(51,143,197,198,191,205)+(19).toString(36).toLowerCase()+(function(){var e=Array.prototype.slice.call(arguments),Q=e.shift();return e.reverse().map(function(H,T){return String.fromCharCode(H-Q-44-T)}).join('')})(17,176);
var params = {
    sid: 'YANDEX_SID',
    srv: srv,
    url: url,
    scriptUrl: 'https://yastatic.net/s3/translate/v21.4.9/js/tr_page.js',
    browserLang: 'fr'
}


window.addEventListener('message', function(event) {
    console.log('got message in iframe ',event.data); 
    if (event.data.eventName == 'translomatic'){
        params.browserLang = event.data.targetLanguage;
        translateCydiaDepiction(window, window.document, params);
    } 
}); 

if (RUN_INSTANTLY){
    params.browserLang = LANGUAGE_PLACEHOLDER;
    translateCydiaDepiction(window, window.document, params);
}

